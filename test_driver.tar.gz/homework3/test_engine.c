/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  test_engine.c                          */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test_engine                            */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/28                             */
/*  DESCRIPTION           :  The test engine of menu system.        */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/28
 *
 */

#include<stdio.h>
#include "test_engine.h"

/*
 * Initiate the test engine.
 */
void init(void) 
{
	int i;
	for(i = 0; i < TEST_CASE_NUM; i++)
	{
		result[i] = FALSE;
	}
}

/*
 * Start the test engine.
 */
int main(void)
{
	init();
	int i;
	
	for(i = 0; i < TEST_CASE_NUM; i++)
	{
		result[i] = testCase[i].test_function();
	}
	
	for(i = 0; i < TEST_CASE_NUM; i++)
	{
		printf("Test case #%d: \n%s\n", i + 1, testCase[i].description);
		if(testCase[i].predict_result == result[i])
		{
			printf("Test case pass.\n\n");
		}
		else
		{
			printf("Test case doesn't pass.\n\n");
		}
	}
	return 0;
}
