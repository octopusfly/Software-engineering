/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  test_engine.h                          */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test_engine                            */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/28                             */
/*  DESCRIPTION           :  The test interface of menu system.     */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/28
 *
 */

#ifndef _TEST_ENGINE_
#define _TEST_ENGINE_

#define TEST_CASE_NUM 33
#define TRUE 1
#define FALSE 0

typedef struct node
{
	char description[255];
	int (*test_function) ();
	int predict_result;
} tTestCase;

int result[TEST_CASE_NUM];
tTestCase testCase[TEST_CASE_NUM];

#endif
