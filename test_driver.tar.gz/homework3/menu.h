/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.h                                 */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/21                             */
/*  DESCRIPTION           :  interface of Command line              */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/21
 * delete search method and add update method, 2014/09/28
 *
 */
 
#ifndef _MENU_H_
#define _MENU_H_
 
#define CMD_LEN 10
#define DES_LEN 255
#define SUCC 1
#define FAIL 0

typedef struct m tMenu;
typedef struct c tCmd;

/*
 * Create a command.
 */
tCmd* CreateCommand(char* command, char* desc, void (*handler)(tMenu *menu));

/*
 * Create an empty menu which contains no command.
 */
tMenu* CreateEmptyMenu(void);

/*
 * Delete a menu.
 */
int DeleteMenu(tMenu* menu);

/*
 * Add a command into a menu.
 */
int AddCommand(tMenu *menu, tCmd *command);
 
/*
 * Delete one commands in menu.
 */
int DeleteCommand(tMenu *menu, tCmd *command);

/*
 * Update the description of a command
 */
int UpdateDescription(tCmd* cmd, char* desc);

/*
 * Update the handler of a command
 */
int UpdateHandler(tCmd* cmd, void (*handler) (tMenu *menu));

/* 
 * Start the menu.
 */
int StartMenu(tMenu* menu);

/*
 * Print Information of a command.
 */
char* ToString(tCmd *command);

/*
 * Print command list.
 */
int PrintMenu(tMenu *menu);

/*
 * Get the number of commands in a menu.
 */
int GetCommandNum(tMenu *menu);

#endif
