/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  stub.c                                 */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test_engine                            */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/28                             */
/*  DESCRIPTION           :  The test stub of menu.h                */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/29
 *
 */

#include<stdio.h>
#include "menu.h"
#include "test_engine.h"

typedef struct m
{
	
} tMenu;

typedef struct c
{
	char cmd[CMD_LEN];
	char desc[DES_LEN];
	void (*handler) (tMenu *menu);
} tCmd;

/*
 * Create a command. 
 */
tCmd* CreateCommand(char* command, char* desc, void (*handler)(tMenu *menu))
{
	return NULL;
}

/*
 * Create an empty menu which contains no command.
 */
tMenu* CreateEmptyMenu(void)
{
	return NULL;
}

/*
 * Delete a menu.
 */
int DeleteMenu(tMenu* menu)
{
	return FAIL;
}

/*
 * Add a command into a menu.
 */
int AddCommand(tMenu *menu, tCmd *command)
{
	return FAIL;
}
 
/*
 * Delete one commands in menu.
 */
int DeleteCommand(tMenu *menu, tCmd *command)
{
	return FAIL;
}

/*
 * Update the description of a command
 */
int UpdateDescription(tCmd* cmd, char* desc)
{
	return FAIL;
}

/*
 * Update the handler of a command
 */
int UpdateHandler(tCmd* cmd, void (*handler) (tMenu *menu))
{
	return FAIL;
}

/* 
 * Start the menu.
 */
int StartMenu(tMenu* menu)
{
	return 0;
}

/*
 * Print Information of a command.
 */
char* ToString(tCmd *command)
{
	return NULL;	
}

/*
 * Print command list.
 */
int PrintMenu(tMenu *menu)
{
	return FAIL;	
}

/*
 * Get the number of commands in a menu.
 */
int GetCommandNum(tMenu *menu)
{
	return -1;
}
