/********************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                    */
/* FILE NAME                    : linklist.c                        */
/* PRINCIPAL AUTHOR             : ZhangYufei                        */
/* SUBSYSTEM NAME               : menu                              */
/* MODULE NAME                  : menu                              */
/* LANGUAGE                     : C                                 */
/* TARGET ENVIRONMENT           : ANY                               */
/* DATE OF FIRST RELEASE        : 2014/09/14                        */
/* DESCRIPTION                  : This file is the implementation   */
/*                                of the functions in file:         */
/*           			  linklist.h                        */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei, 2014/09/14
 *
 */

#include<string.h>
#include"linklist.h"

tDataNode head[CMD_NUM] = 
{
	{"help", "This is the help command.", help, head + 1},
	{"version", "Version: Menu Program V1.0", NULL, NULL}
};

/* compare the input with the commands in the list */ 
int check(const char *str1, const char *str2);

tDataNode* getCmd(char *input)
{
	tDataNode *p = head;
    while(p != NULL) 
    {
        if(check(p -> command, input))
        {
            printf("%s\n", p -> desc);
            if(p -> handler != NULL)
            {
            	p -> handler();
            }
            break;
        }    
        else
        {
            p = p -> next;
        }
    }
    if(p == NULL) 
    {
        printf("You've typed the wrong command!!\n");
    }
}

int check(const char *str1, const char *str2) 
{
    return strcmp(str1, str2) == 0;
}
