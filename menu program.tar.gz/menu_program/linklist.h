/********************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                    */
/* FILE NAME                    : linklist.h                        */
/* PRINCIPAL AUTHOR             : ZhangYufei                        */
/* SUBSYSTEM NAME               : menu                              */
/* MODULE NAME                  : menu                              */
/* LANGUAGE                     : C                                 */
/* TARGET ENVIRONMENT           : ANY                               */
/* DATE OF FIRST RELEASE        : 2014/09/14                        */
/* DESCRIPTION                  : This file define the data         */
/*                                sturcture and the operations.     */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei, 2014/09/14
 *
 */

#include<stdio.h>
#include"command.h"

#define CMD_NUM 2
#define CMD_LEN 20
#define DESC_LEN 100

typedef struct DataNode 
{
     char command[CMD_LEN];
     char desc[DESC_LEN];
     int  (*handler) ();
     struct DataNode *next;
} tDataNode;

tDataNode head[CMD_NUM]; 

/* Pitch the command according to the input string. */
tDataNode* getCmd(char *input);

/* Print the name and description of all commands. */
void printAllCmd(void);
