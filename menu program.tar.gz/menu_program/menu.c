/********************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                    */
/* FILE NAME                    : menu.c                            */
/* PRINCIPAL AUTHOR             : ZhangYufei                        */
/* SUBSYSTEM NAME               : menu                              */
/* MODULE NAME                  : menu                              */
/* LANGUAGE                     : C                                 */
/* TARGET ENVIRONMENT           : ANY                               */
/* DATE OF FIRST RELEASE        : 2014/09/08                        */
/* DESCRIPTION                  : This is a menu program.           */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei, 2014/09/08
 * 1st change: divide the program into two .c files. 2014/09/14
 *
 */

#include<stdio.h>
#include"linklist.h"
#include"command.h"

/* Initiate the linklist */
tDataNode* init(void);

/* Start the menu, asking user to type */
void startMenu(tDataNode *head);


int main(void)
{
    startMenu(head);
    return 0;
}

void startMenu(tDataNode *head)
{
    printf("Type your command please: \n");
    char input[CMD_LEN];
    while(scanf("%s", input)) 
    {
        getCmd(input);
    }
}
