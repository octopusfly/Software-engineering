/********************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                    */
/* FILE NAME                    : command.h                         */
/* PRINCIPAL AUTHOR             : ZhangYufei                        */
/* SUBSYSTEM NAME               : menu                              */
/* MODULE NAME                  : menu                              */
/* LANGUAGE                     : C                                 */
/* TARGET ENVIRONMENT           : ANY                               */
/* DATE OF FIRST RELEASE        : 2014/09/14                        */
/* DESCRIPTION                  : This file contains the functions  */
/*                                executing the commands.           */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei, 2014/09/14
 *
 */
 
 /* This function is the execution of the command: help */
int help(void);

