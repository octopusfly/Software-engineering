Project name       :   menu
Author             :   Zhangyufei
Create Date        :   2014/09/14

Function :
    This tiny program is an imitation of the command line in linux. There are two commands availiable: version and help. Start the program and you will get the tip: Type your command Please. Type "help", you can get the current command list; and type "version", you can get the version of this program.

The method of compile : 
    Run this program in the linux terminal. Type the commands as following:
	root@ubuntu:~$ gcc menu.c linklist.c command.c -o menu
        root@ubuntu:~$ ./menu
    And then, enjoy it!!!!
