/********************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                    */
/* FILE NAME                    : command.h                         */
/* PRINCIPAL AUTHOR             : ZhangYufei                        */
/* SUBSYSTEM NAME               : menu                              */
/* MODULE NAME                  : menu                              */
/* LANGUAGE                     : C                                 */
/* TARGET ENVIRONMENT           : ANY                               */
/* DATE OF FIRST RELEASE        : 2014/09/14                        */
/* DESCRIPTION                  : This file is the implement of     */
/*                                file: command.h                   */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei, 2014/09/14
 *
 */
 
#include"command.h"
#include"linklist.h"

int help(void)
{	printf("------------------------------------------\n");
	printf("Command list:\n");
	tDataNode *p = head;
	while(p != NULL)
	{ 	
		printf("%s - %s\n", p -> command, p -> desc);
		p = p -> next;		
  	}
	printf("------------------------------------------\n");
	return 1;
}
