/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.c                                 */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  Menu                                   */
/*  MODULE NAME           :  Menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/21                             */
/*  DESCRIPTION           :  implement of Menu.h                    */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/21
 *
 */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"linktable.h"
#include"menu.h"

/*
 * Private variable
 * Save the current input command.
 */
char* currentInput;

int CheckString(tLinkTableNode *node);

typedef struct c 
{
    tLinkTableNode *pNext;
    char name[CMD_LEN];
    char desc[DES_LEN];
    void (*handler) (tMenu *menu);
} tCmd;

typedef struct m 
{
    tLinkTable *linktable;
    int numOfCommand;
} tMenu;

/*
 * Create a command.
 */
tCmd* CreateCommand(char* command, char* desc, void handler (tMenu *menu))
{
    tCmd *tcmd;
    tcmd = (tCmd*) malloc(sizeof(tCmd));
    tcmd -> pNext = NULL;
    strcpy(tcmd -> name, command);
    strcpy(tcmd -> desc, desc);
    tcmd -> handler = handler;
    return tcmd;
}

/*
 * Create an empty menu which contains no command.
 */
tMenu* CreateEmptyMenu(void)
{
    tMenu *menu = (tMenu*) malloc(sizeof(tMenu));
    menu -> linktable = CreateLinkTable();
    menu -> numOfCommand = 0;
    return menu;
} 

/*
 * Delete a menu.
 */
int DeleteMenu(tMenu* menu)
{
    if(menu == NULL)
    {
        return FAIL;
    }
    DeleteLinkTable(menu -> linktable);
    free(menu);
    return SUCC;
}

/*
 * Add a command into a menu.
 */
int AddCommand(tMenu *menu, tCmd *command) 
{
    if(menu == NULL || command == NULL)
    {
        return FAIL;
    }
    AddLinkTableNode(menu -> linktable, (tLinkTableNode*) command);
    menu -> numOfCommand++;
    return SUCC;
}
    
/*
 * Get one command according to id.
 */
tCmd* GetCommandById(tMenu *menu, int id)
{
    if(id > menu -> numOfCommand)
    {
        return NULL;
    }
    tLinkTableNode *node = GetLinkTableHead(menu -> linktable);
    int i;
    for(i = 2; i <= id; i++)
    {
        node = GetNextLinkTableNode(menu -> linktable, node);
    }
    return (tCmd*)node;
}

/* 
 * Get one command from menu according to command string.
 */
 tCmd* GetCommandByString(tMenu *menu, char* command)
 {
    if(menu == NULL)
    {
        return NULL;     
    }
    currentInput = command;
    tLinkTableNode *node = SearchLinkTableNode(menu->linktable, CheckString);
    
	return (tCmd*) node;
 }
 
/*
 * Delete one commands in menu according to input string.
 */
int DeleteCommandByString(tMenu *menu, char* cmd)
{
    if(menu == NULL || cmd == NULL)
    {
        return FAIL;
    }
    currentInput = cmd;
    tLinkTableNode *node =  SearchLinkTableNode(menu -> linktable, CheckString);
    DelLinkTableNode(menu -> linktable, node);
    menu -> numOfCommand--;
    
	return SUCC;
}

/* 
 * Start the menu.
 */
int StartMenu(tMenu* menu)
{
    tLinkTableNode *head = GetLinkTableHead(menu -> linktable);
    tLinkTableNode *node = head;
    
    printf("\nMenu program. Version 1.0 >");
    char input[CMD_LEN];
    while(scanf("%s", input)) 
    {
        if(strcmp(input, "quit") == 0)
        {
            printf("Good bye!\n");
            break;
        }
        tCmd *command = (tCmd*) GetCommandByString(menu, input);
        if(command != NULL && command -> handler!= NULL)
        {
            command -> handler(menu);
        } 
        else
        {
                printf("Invalid command.\n");
        }
        printf("\nMenu program. Version 1.0 >");
    }
    return SUCC;
}

/*
 * Print Information of a command.
 */
void ToString(tCmd *command)
{
        printf("%s: %s\n", command -> name, command -> desc);
}

/*
 * Print command list.
 */
void printMenu(tMenu *menu)
{
    int i;
    printf("Command List:\n");
    printf("--------------------------------------------------\n");
    for(i = 0; i < menu -> numOfCommand; i++)
    {
        tCmd *tcmd = GetCommandById(menu, i + 1);
        ToString(tcmd);
    }
    printf("quit: Exit the system.\n");
        printf("--------------------------------------------------\n");
}

/*
 * Private function.
 * Compare the input with the command string.
 */
int CheckString(tLinkTableNode *node)
{
    if(strcmp(((tCmd*) node) -> name, currentInput) == 0)
    {
        return 0;
    }
    else
	{
        return -1;
	}
} 
