/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  menu.h                                 */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/21                             */
/*  DESCRIPTION           :  interface of Command line              */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/21
 *
 */
 
#ifndef _MENU_H_
#define _MENU_H_
 
#define CMD_LEN 10
#define DES_LEN 255
#define SUCC 1
#define FAIL (-1)

typedef struct m tMenu;
typedef struct c tCmd;

/*
 * Create a command.
 */
tCmd* CreateCommand(char* command, char* desc, void (*handler)(tMenu *menu));

/*
 * Create an empty menu which contains no command.
 */
tMenu* CreateEmptyMenu(void);

/*
 * Delete a menu.
 */
int DeleteMenu(tMenu* menu);

/*
 * Add a command into a menu.
 */
int AddCommand(tMenu *menu, tCmd *command);
    
/*
 * Get one command from menu according to id.
 */
tCmd* GetCommandById(tMenu *menu, int id);

/* 
 * Get one command from menu according to command string.
 */
tCmd* GetCommandByString(tMenu *menu, char* command);
 
/*
 * Delete one commands in menu according to input string.
 */
int DeleteCommandByString(tMenu *menu, char* cmd);

/* 
 * Start the menu.
 */
int StartMenu(tMenu* menu);

/*
 * Print Information of a command.
 */
void ToString(tCmd *command);

/*
 * Print command list.
 */
void printMenu(tMenu *menu);

#endif
