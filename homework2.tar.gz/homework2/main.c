/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  menu.c                                 */
/*  PRINCIPAL AUTHOR      :  ZhangYufei                             */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/21                             */
/*  DESCRIPTION           :  Testing Code.                          */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangYufei,2014/09/21
 *
 */

#include<stdio.h>
#include"menu.h"

void version(tMenu *menu);
void help(tMenu *menu);

int main(void)
{
    tMenu *menu = CreateEmptyMenu();
    tCmd *c_version = CreateCommand("version", "Version Message", version);
    tCmd *c_help = CreateCommand("help", "Get help information", help);
    AddCommand(menu, c_version);
    AddCommand(menu, c_help);
    StartMenu(menu);
    return 0;
}

void version(tMenu *menu) 
{
    printf(" Menu Program.\n Version 1.0\n Author: Octopusfly\n");
}

void help(tMenu *menu)
{
    printMenu(menu);
}
