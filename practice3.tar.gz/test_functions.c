/********************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                */
/*                                                                  */
/*  FILE NAME             :  test_functions.c                       */
/*  PRINCIPAL AUTHOR      :  lijiuxian                              */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test_engine                            */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/29                             */
/*  DESCRIPTION           :  The implements of test functions.      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by lijiuxian,2014/09/29
 *
 */

#include<stdio.h>
#include<string.h>
#include "menu.h"
#include "test_driver.h"

/*
 * define the test function as follows:
 *
 */
 
/*
 * Test the function: CreateCommand.
 1 all parameters are available.2 The handler is null.3 The cmd is null.4 The description is null.
 */
int test_CreateCommand1();
int test_CreateCommand2();
int test_CreateCommand3();
int test_CreateCommand4();

/*
 * Test the function: CreateEmptyMenu.
 * Create an empty menu which contains no command.
 */
int test_CreateEmptyMenu();

/*
 * Test the function: DeleteMenu.1 Menu is empty. 2 menu have commands. 3 menu is null.
 */
int test_DeleteMenu1();
int test_DeleteMenu2();
int test_DeleteMenu3();

/*
 * Test function: AddCommand.1: Add a command to  empty menu. 2: Add a command to a menu which have some commands.
 * 3: Add a null command to menu. 4: Add a command to a null menu. 
 *5: Add a command to an menu. 6 The command has a name which is already exist in the menu.
 */
int test_AddCommand1();
int test_AddCommand2();
int test_AddCommand3();
int test_AddCommand4();
int test_AddCommand5();

/*
 * Test function: DeleteCommand.
 * 1: Delete command from a empty menu.2: Delete a null command.
 * 3: Delete a command which is not exist.4: Delete a command from a null menu;
 */
int test_DeleteCommand1();
int test_DeleteCommand2();
int test_DeleteCommand3();
int test_DeleteCommand4();

/*
 * Test function: UpdateDescription.
 * 1: Set the description of a command to a new string.
 * 2: Set the description of a null command to a new string.
 * 3: Set the description of a command to a null string.
 */
int test_UpdateDescription1();
int test_UpdateDescription2();
int test_UpdateDescription3();

/*
 * Test function: UpdateHandler.
 * Set a new handler/a null handler to a command/a null handler.
 */
int test_UpdateHandler1();
int test_UpdateHandler2();
int test_UpdateHandler3();

/*
 * Test function: StartMenu.
 * 1: Start a simple menu. 2: Start an empty menu. 3: Start an null menu.
 */
int test_StartMenu1();
int test_StartMenu2();
int test_StartMenu3();

/*
 * Test function: ToString.
 * Get the information of a command/null command. 
 */
int test_ToString1();
int test_ToString2();

/*
 * Test function: PrintMenu.
 * 1: Print the message of a menu/a null menu;
 */
int test_PrintMenu1();
int test_PrintMenu2();

/*
 * Test function: GetCommandNum
 * 1: Get the number of commands of a menu/a empty menu/a null menu.
 */
int test_GetCommandNum1();
int test_GetCommandNum2();
int test_GetCommandNum3();

tTestCase testCase[TEST_CASE_NUM] =
{
	{"CreateCommand with all parameters available.", test_CreateCommand1, TRUE}, 
	{"CreateCommand with the handler null.", test_CreateCommand2, TRUE},
	{"CreateCommand with the cmd null.", test_CreateCommand3, FALSE},
	{"CreateCommand with the description null.", test_CreateCommand4, TRUE},
	{"Create an empty menu which contains no command.", test_CreateEmptyMenu, TRUE},
	{"Delete a menu which is empty.", test_DeleteMenu1, TRUE},
	{"Delete a menu which contains some commands.", test_DeleteMenu2, TRUE},
	{"Delete a null menu", test_DeleteMenu3, FALSE},
	{"Add a command to an empty menu.", test_AddCommand1, TRUE},
	{"Add a command to a menu which contains some commands.", test_AddCommand2, TRUE},
	{"Add a null command to an menu.", test_AddCommand3, FALSE},
	{"Add a command to a null menu.", test_AddCommand4, FALSE},
	{"Add a command to an menu.The command has a name which is already exist in the menu.", test_AddCommand5, FALSE},
	{"Delete command from a empty menu.", test_DeleteCommand1, FALSE},
	{"Delete a null command from a menu.", test_DeleteCommand2, TRUE},
	{"Delete a command which is not exist in the menu.", test_DeleteCommand3, FALSE},
	{"Delete a command from a null menu;", test_DeleteCommand4, FALSE},
	{"Set the description of a command to a new string.", test_UpdateDescription1, TRUE},
	{"Set the description of a null command to a new string.", test_UpdateDescription2, FALSE},
	{"Set the description of a command to a null string.", test_UpdateDescription2, TRUE},
	{"Set a new handler to a command.", test_UpdateHandler1, TRUE},
	{"Set a null handler to a command.", test_UpdateHandler2, TRUE},
	{"Set a new handler to a null command.", test_UpdateHandler3, FALSE},
	{"Start a simple menu.", test_StartMenu1, TRUE},
	{"Start an empty menu.", test_StartMenu2, TRUE},
	{"Start an null menu.", test_StartMenu3, FALSE},
	{"Get the information of a command.", test_ToString1, TRUE},
	{"Get the information of a null command.", test_ToString2, FALSE},
	{"Print the message of a menu;", test_PrintMenu1, TRUE},
	{"Print the message of a null menu;", test_PrintMenu2, FALSE},
	{"Get the number of commands of a menu.", test_GetCommandNum1, TRUE},
	{"Get the number of commands of a empty menu.", test_GetCommandNum2, TRUE},
	{"Get the number of commands of a null menu.", test_GetCommandNum3, FALSE}
};

void handler(tMenu *menu);
void handler2(tMenu *menu);

/*
 * Test the function: CreateCommand with all parameters available.
 */
int test_CreateCommand1()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	if(cmd != NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test the function: CreateCommand with the handler null.
 */
int test_CreateCommand2()
{
	tCmd *cmd = CreateCommand("cmd", "command example", NULL);
	if(cmd != NULL)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test the function: CreateCommand with the cmd null.
 */
int test_CreateCommand3()
{
	tCmd *cmd = CreateCommand(NULL, "command example", handler);
	if(cmd != NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test the function: CreateCommand with the description null.
 */
int test_CreateCommand4()
{
	tCmd *cmd = CreateCommand("cmd", NULL, handler);
	if(cmd != NULL)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test the function: CreateEmptyCommand.
 */
int test_CreateEmptyMenu()
{
	tMenu *menu = CreateEmptyMenu();
	if(menu != NULL && GetCommandNum(menu) == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test the function: DeleteMenu, delete a menu which is empty.
 */
int test_DeleteMenu1()
{
	tMenu *menu = CreateEmptyMenu();
	int result = DeleteMenu(menu);
	if(result == SUCC && menu == NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test the function: DeleteMenu, delete a menu which contains some commands.
 */
int test_DeleteMenu2()
{
	tMenu *menu = CreateEmptyMenu();
	tCmd *cmd1, *cmd2;
	cmd1 = CreateCommand("cmd1", "command example", handler);
	cmd1 = CreateCommand("cmd2", "command example", handler);
	AddCommand(menu, cmd1);
	AddCommand(menu, cmd2);
	int result = DeleteMenu(menu);
	if(result == SUCC && menu == NULL && cmd1 == NULL && cmd2 == NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: DeleteMenu.
 * Delete a null menu.
 */
int test_DeleteMenu3() 
{
	int result = DeleteMenu(NULL);
	if(result == SUCC)
	{
		return TRUE;
	} 
	else
	{
		return FALSE; 
	}
}

/*
 * Test function: AddCommand, add a command to an empty menu.
 */
int test_AddCommand1()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	tMenu *menu = CreateEmptyMenu();
	int result = AddCommand(menu, cmd);
	if(result == SUCC && GetCommandNum(menu) == 1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: AddCommand, add a command to a menu 
 * which contains some commands.
 */
int test_AddCommand2()
{
	tCmd *cmd1, *cmd2, *cmd3;
	cmd1 = CreateCommand("cmd1", "example command", handler);
	cmd2 = CreateCommand("cmd3", "example command", handler);
	cmd3 = CreateCommand("cmd3", "example command", handler);
	tMenu *menu = CreateEmptyMenu();
	AddCommand(menu, cmd1);
	AddCommand(menu, cmd2);
	int cmd_num = GetCommandNum(menu);
	int result = AddCommand(menu, cmd3);
	if(result == SUCC && GetCommandNum(menu) == cmd_num + 1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: AddCommand, add a null command to an menu.
 */
int test_AddCommand3()
{
	tMenu *menu = CreateEmptyMenu();
	int result = AddCommand(menu, NULL);
	if(result == SUCC && GetCommandNum(menu) == 1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: Add a command to a null menu.
 */
int test_AddCommand4() 
{
	tCmd *cmd = CreateCommand("cmd", "example cmd", handler);
	int result = AddCommand(NULL, cmd);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: AddCommand, add a command to an menu.
 * The command has a name which is already exist in the menu.
 */
int test_AddCommand5()
{
	tCmd *cmd1, *cmd2;
	cmd1 = CreateCommand("cmd", "example command", handler);
	cmd2 = CreateCommand("cmd", "example command", handler);
	tMenu *menu = CreateEmptyMenu();
	AddCommand(menu, cmd1);
	int cmd_num = GetCommandNum(menu);
	int result = AddCommand(menu, cmd2);
	if(result == SUCC && GetCommandNum(menu) == cmd_num + 1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: DeleteCommand, delete command from a empty menu.
 */
int test_DeleteCommand1()
{
	tMenu *menu = CreateEmptyMenu();
	int cmd_num = GetCommandNum(menu);
	tCmd *cmd = CreateCommand("cmd", "command example", handler);
	int result = DeleteCommand(menu, cmd);
	if(result == SUCC && cmd == NULL && GetCommandNum(menu) == cmd_num - 1)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test function: DeleteCommand, delete a null command from a empty menu.
 */
int test_DeleteCommand2()
{
	tMenu *menu = CreateEmptyMenu();
	int cmd_num = GetCommandNum(menu);
	int result = DeleteCommand(menu, NULL);
	if(result == SUCC && GetCommandNum(menu) == cmd_num - 1)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test function: DeleteCommand, delete a command 
 * which is not exist in the menu.
 */
int test_DeleteCommand3()
{
	tCmd *cmd1, *cmd2, *cmd3;
	cmd1 = CreateCommand("cmd1", "example command", handler);
	cmd2 = CreateCommand("cmd2", "example command", handler);
	cmd3 = CreateCommand("cmd3", "example command", handler);
	tMenu *menu = CreateEmptyMenu();
	AddCommand(menu, cmd1);
	AddCommand(menu, cmd2);
	int cmd_num = GetCommandNum(menu);
	int result = DeleteCommand(menu, cmd3);
	if(result == SUCC && GetCommandNum(menu) == cmd_num - 1)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test function: DeleteCommand, delete a command 
 * from a null menu;
 */
int test_DeleteCommand4()
{
	tCmd *cmd1, *cmd2, *cmd3;
	cmd1 = CreateCommand("cmd1", "example command", handler);
	cmd2 = CreateCommand("cmd2", "example command", handler);
	cmd3 = CreateCommand("cmd3", "example command", handler);
	tMenu *menu = NULL;
	int cmd_num = GetCommandNum(menu);
	int result = DeleteCommand(NULL, cmd3);
	if(result == SUCC && GetCommandNum(menu) == cmd_num - 1)
	{
		return TRUE;
	}
	else 
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateDescription.
 * Set the description of a command to a new string.
 */
int test_UpdateDescription1()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	char new_string[DES_LEN] = "new description";
	int result = UpdateDescription(cmd, new_string);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateDescription.
 * Set the description of a null, command to a new string.
 */
int test_UpdateDescription2()
{
	char new_string[DES_LEN] = "new description";
	int result = UpdateDescription(NULL, new_string);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateDescription.
 * Set the description of a command to a null string.
 */
int test_UpdateDescription3()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	int result = UpdateDescription(cmd, NULL);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateHandler.
 * Set a new handler to a command.
 */
int test_UpdateHandler1()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	int result = UpdateHandler(cmd, handler2);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateHandler.
 * Set a null handler to a command.
 */
int test_UpdateHandler2()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	int result = UpdateHandler(cmd, NULL);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: UpdateHandler.
 * Set a new handler to a null command.
 */
int test_UpdateHandler3()
{
	int result = UpdateHandler(NULL, handler);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: StartMenu.
 */
int test_StartMenu1()
{
	tMenu *menu = CreateEmptyMenu();
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	int result = StartMenu(menu);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: StartMenu.
 * Start an empty menu.
 */
int test_StartMenu2()
{
	tMenu *menu = CreateEmptyMenu();
	int result = StartMenu(menu);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: StartMenu.
 * Start an null menu.
 */
int test_StartMenu3()
{
	int result = StartMenu(NULL);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: ToString.
 * Get the information of a command.
 */
int test_ToString1()
{
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	char *result = ToString(cmd);
	if(result != NULL && strcmp("cmd-example command", result) == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: ToString.
 * Get the information of a null command.
 */
int test_ToString2()
{
	char *result = ToString(NULL);
	if(result != NULL)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: PrintMenu.
 * Print the message of a menu;
 */
int test_PrintMenu1()
{
	tMenu *menu = CreateEmptyMenu();
	int result = PrintMenu(menu);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: PrintMenu.
 * Print the message of a null menu;
 */
int test_PrintMenu2()
{
	int result = PrintMenu(NULL);
	if(result == SUCC)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: GetCommandNum
 * Get the number of commands of a menu.
 */
int test_GetCommandNum1()
{
	tMenu *menu = CreateEmptyMenu();
	tCmd *cmd = CreateCommand("cmd", "example command", handler);
	int result = GetCommandNum(menu);
	if(result == 1)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: GetCommandNum
 * Get the number of commands of a empty menu.
 */
int test_GetCommandNum2()
{
	tMenu *menu = CreateEmptyMenu();
	int result = GetCommandNum(menu);
	if(result == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Test function: GetCommandNum
 * Get the number of commands of a null menu.
 */
int test_GetCommandNum3()
{
	int result = GetCommandNum(NULL);
	if(result == 0)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/*
 * Private function: handler example1.
 */
void handler(tMenu *menu) 
{
	
}

/*
 * Private function: handler example2.
 */
void handler2(tMenu *menu)
{
	
}
